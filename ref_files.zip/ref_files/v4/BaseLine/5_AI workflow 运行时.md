# 5. AI workflow 运行时

> 读完这一篇，AI 应该能回答：用户拖一份 PDF 进 AI Panel 之后，从前端到 DB 的完整链路是什么 / 怎么加新 capability / 怎么改 workflow / 怎么扩展 categories / 审计字段是什么。

---

## 1. AI 系统的总览

```
┌─────────────────────────────────────────────────────────────────────┐
│                          AI Panel UI (Svelte 5)                      │
│  src/app/ai-panel/components/workflow-panel/                        │
│  ├─ QuickActions / TodayBrief / TaskLine                            │
│  └─ ActiveFlow → layers/<workflow>/Step.svelte                       │
└────────┬────────────────────────────────────────────────────────────┘
         │
         │ POST /api/documents (Ship 2C: upload → Inbox)
         │ GET /api/documents/inbox + /api/documents/[id]
         │ GET /api/documents/[id]/intake（rawText / 分类诊断）
         │ POST /api/documents/[id]/{reclassify,confirm}
         │
         │ legacy deterministic workflows still use:
         │ POST /api/finance/workflow + /advance + /confirm
         │
┌────────▼────────────────────────────────────────────────────────────┐
│                       Workflow Runtime (KV)                          │
│  src/platform/workflow/workflow-runtime.ts                          │
│  state machine: trigger → document_intake → bucket_selection → ...  │
└────────┬────────────────────────────────────────────────────────────┘
         │
         │ 在每个 step 调对应 capability
         │
┌────────▼────────────────────────────────────────────────────────────┐
│                   Capability Registry + Tool Policy                  │
│  src/platform/ai/{capability-registry,tool-policy}.ts               │
│  - 9 点检查（agent / user permission / risk / confirmation）         │
│  - 调用 capability.execute()                                         │
│  - 写 audit log（model id / prompt version / final action）          │
└────────┬────────────────────────────────────────────────────────────┘
         │
         │ AI Runtime + Document Intake
         │
┌────────▼────────────────────────────────────────────────────────────┐
│  AI Runtime: runStructuredOutput()                                   │
│    src/platform/ai/ai-runtime.ts                                    │
│    Workers AI / OpenAI provider dispatch；fallback 由 capability 自定 │
│                                                                       │
│  Document Intake: artifact 状态机 + OCR + 分类                       │
│    src/modules/document-intake/services/document-intake-service.ts  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 2. 端到端 demo 链路（拖一份 axiom 发票 PDF，Ship 2C）

完整路径，按用户操作顺序：

| # | 用户动作 | 前端文件 | 后端调用 | 关键效果 |
|---|---|---|---|---|
| 1 | 点 AI Panel 的 "录发票" Quick Action | `app/ai-panel/components/workflow-panel/layers/QuickActions.svelte` | — | UI panel 切换到 `financial-document-intake` 上传层，保留 category hint |
| 2 | 拖 PDF / 图片 / ZIP 或一次选择多个文件到 UploadStep | `layers/finance-document-intake/UploadStep.svelte` | `POST /api/documents` (multipart，逐文件调用) | 前端支持 `multiple` 文件选择（`src/app/ai-panel/components/workflow-panel/layers/finance-document-intake/UploadStep.svelte:388`），ZIP 在浏览器用 `fflate` 展开并过滤成 PDF / 图片（`:136`），然后按顺序逐个上传（`:217` / `:235`），每个文件仍单独走 `createDocumentFromUpload` 写 R2 + `documentArtifact`；生产推 `DOCUMENT_QUEUE` 后立返 202，本地 localhost 默认 inline 处理避免卡 `stored` |
| 3 | AI Panel 切到 Inbox 浮层 | `layers/finance-inbox/InboxLayer.svelte` | `GET /api/documents/inbox` / `GET /api/documents/[id]` | 显示 processing / ready / confirmed / failed；不再调用 `/api/finance/workflow/[id]/advance` 的 `document_intake` |
| 4 | Worker 异步处理 | `workers/document-processor.ts` | — | `processDocument({ fieldExtractor })` 跑 text extraction → classify → finance.extract-document-fields；字段输出使用选中 category 的 snake_case `llmFields`，artifact 到 `ready_for_review` |
| 5 | 用户在 AI Panel 或 `/finance/inbox/[id]` review | `app/components/document-intake/DocumentIntakeDiagnostics.svelte` + `app/components/finance-inbox/InboxConfirmForm.svelte` | `GET /api/documents/[id]/intake` + `POST /api/documents/[id]/reclassify`（可选） + `GET /api/projects`（project picker） | 先验证 document-intake 的 rawText / coarse documentType / file preview；AI Panel 两栏 review 见 `src/app/ai-panel/components/workflow-panel/layers/finance-inbox/InboxLayer.svelte:299` + raw text `:363`；右侧 TaskLine bubbles 来自 `src/app/ai-panel/workflow/registry.ts:128`，确认表单用 `panel.setStep` 同步（`src/app/components/finance-inbox/InboxConfirmForm.svelte:271` / `:276`）。内容步骤为 category（`:485`）→ suggested fields（`:558`）→ project link（`:626`）。改 finance category 时用同一 raw text 重跑 `extract-document-fields`（路由注释 `src/routes/api/documents/[id]/reclassify/+server.ts:16`），状态保持 `ready_for_review` |
| 6 | 用户确认 | `InboxConfirmForm.svelte` | `POST /api/documents/[id]/confirm` | 提交 category-specific `fields: Record<string, unknown>` + payload sha256；confirm 路由 normalize 到 expenses/revenue 主表公共字段，并把 invoice/receipt/PO/tracking/line_items 等稀疏字段写入 `metadata`；archive 尚按 endpoint 能力返回 |

**端到端文件清单**：

| 后端 | 路径 |
|---|---|
| Document upload + queue/inline fallback | `src/routes/api/documents/+server.ts` → `src/modules/document-intake/services/document-intake-service.ts` |
| Inbox list/detail/categories/intake diagnostics | `src/routes/api/documents/{inbox,categories}/+server.ts` + `src/routes/api/documents/[id]/{+server,intake/+server}.ts` |
| Inbox confirm/reclassify | `src/routes/api/documents/[id]/{confirm,reclassify}/+server.ts` |
| Workflow start | `src/routes/api/finance/workflow/+server.ts` |
| Workflow advance (per step) | `src/routes/api/finance/workflow/[id]/advance/+server.ts` |
| Workflow confirm + write | `src/routes/api/finance/workflow/[id]/confirm/+server.ts` |
| Document status polling | `src/routes/api/documents/[id]/status/+server.ts` |

| 前端 | 路径 |
|---|---|
| AI Panel 入口 | `src/app/ai-panel/components/workflow-panel/PanelTrigger.svelte` |
| Workflow panel 主壳 | `src/app/ai-panel/components/workflow-panel/WorkflowPanel.svelte` |
| 路由分发 | `src/app/ai-panel/components/workflow-panel/layers/ActiveFlow.svelte`（按 workflowId 选 layer） |
| financial-document-intake 上传入口 | `src/app/ai-panel/components/workflow-panel/layers/finance-document-intake/UploadStep.svelte`（支持多文件/ZIP；ZIP 展开见 `:136`，逐文件上传见 `:235`，上传后切 `finance-inbox`） |
| AI Panel Inbox 浮层 | `src/app/ai-panel/components/workflow-panel/layers/finance-inbox/InboxLayer.svelte`（详情态两栏：左侧 `InboxConfirmForm`，右侧 document preview + raw text review，见 `:299` / `:347` / `:363`） |
| document-intake 诊断面板 | `src/app/components/document-intake/DocumentIntakeDiagnostics.svelte` |
| 共享确认表单 | `src/app/components/finance-inbox/InboxConfirmForm.svelte`（task-driven：先确认 category，再显示 `llmFields + userFields`，最后用 `/api/projects` 搜索下拉关联 project；AI Panel 里步骤显示在右侧 TaskLine bubbles，不在表单顶部；不是固定 invoice 字段，也不让用户手填 `project_id`） |
| Expo Go mobile MVP | `mobile/App.tsx:102`（登录 / 拍照 / Processing + Ready inbox / 三步确认），API wrapper 在 `mobile/src/api.ts:78` 复用 `POST /api/documents`，`mobile/src/api.ts:98` 复用 `/api/documents/inbox`，`mobile/src/api.ts:149` 复用 `/api/documents/[id]/confirm` |
| Phase 1 vendor-invoice-intake 6 步 | `src/app/ai-panel/components/workflow-panel/layers/finance-invoice/` |
| Allowance 流程 | `src/app/ai-panel/components/workflow-panel/layers/finance-allowance/` |

---

## 3. financial-document-intake workflow（canonical）

### 3.1 状态机

10 个 step（来自 `src/modules/finance/workflows/financial-document-intake/definition.ts`）：

```
trigger
  ↓
document_intake          ← legacy artifact 绑定（Ship 2C 主路已由 Inbox 管线接管）
  ↓
bucket_selection         ← 用户选 expense / revenue / archive
  ↓
category_selection       ← 选 15 个 categories 中的具体一个
  ↓
field_extraction         ← AI 抽字段（按 categoryDocType 分支）
  ↓
matching                 ← match-supplier + match-purchase-order + detect-duplicate
  ↓
project_selection        ← 选 / 关联 project（sales_cost 必选）
  ↓
user_confirmation        ← 用户最终确认
  ↓
record_creation          ← 写入 expenses / revenue / project archive
  ↓
completion               ← 显示 entityId + auditRef
```

每个 step 有：
- `allowedCapabilities`（这一步能调哪些 capability）
- `riskLevel`（R0-R5）
- `requiresUserConfirmation`（是否需要等用户点 confirm）
- `nextSteps`（合法转移目标）

**Ship 2C 注意**：AI Panel 上传主路不再把 artifact 推进到 finance workflow 的 `document_intake` step；`document_intake.allowedCapabilities` 为空，避免 `finance-agent` 越权调用 `document-intake.classify-document`。分类与字段抽取由 `/api/documents` → Queue/Worker → Inbox 管线负责。

### 3.2 Categories（15 项真理表）

`src/modules/finance/workflows/financial-document-intake/categories.ts`。这是单一真理来源——所有 prompt / schema / 持久化路由 / UI chips 都从这里查。

形状：
```typescript
{
  id: 'expense.opex.transport',
  bucket: 'expense' | 'revenue' | 'document_only',
  expenseType: 'opex' | 'sales_cost' | null,  // null for revenue/archive
  category: ExpenseCategory | null,           // 15 种 expense category enum
  expenseDocType: ExpenseDocType | null,      // invoice / receipt / po
  categoryDocType: CategoryDocType,           // 更宽：含 invoice_out / contract / quotation / purchase_order_doc
  label: '...',
  llmFields: [...],     // AI 抽取 field 列表
  userFields: [...],    // 用户 review step 显示的 field
  defaultFlags: { reimbursement?, businessTrip? },
  requiresProject: boolean,
  persistTarget: 'expenses' | 'revenue' | 'contracts' | 'quotations' | 'purchase_orders' | null
}
```

15 项分布：
- 11 个 expense category（opex × N + sales_cost × N）
- 1 个 revenue
- 3 个 archive（contract / quotation / purchase_order）

**加新 category 永远只动这一份表 + 在 `extract-document-fields/capability.ts` 里加对应 prompt 分支**。

### 3.3 Steps runner

`src/modules/finance/workflows/financial-document-intake/steps.ts` 定义每个 step 的运行函数。advance 路由调它。

### 3.4 Workflow definition（注册）

`src/modules/finance/workflows/financial-document-intake/index.ts` export `financialDocumentIntakeWorkflow`，被 `src/modules/finance/workflows/index.ts` aggregate 到 `financeWorkflows`。

---

## 4. Capabilities（7 个 finance + 1 个 document-intake）

| ID | 模块 | Risk | 用途 | 文件 |
|---|---|---|---|---|
| `finance.extract-invoice-fields` | finance | R2 | Phase 1 demo capability（仅 vendor invoice） | `src/modules/finance/capabilities/extract-invoice-fields/` |
| `finance.extract-document-fields` | finance | R2 | Phase 3 多 docType 抽字段（按 categoryDocType 分支，覆盖 invoice / receipt / po / customer invoice / archive contract / quotation / purchase_order_doc；真实文本走 LLM-only，见 `src/modules/finance/capabilities/extract-document-fields/capability.ts:293`；Inbox 输出 category-specific snake_case keys；legacy workflow 可请求 common projection） | `src/modules/finance/capabilities/extract-document-fields/` |
| `finance.match-supplier` | finance | R0 | fuzzy match 现有 supplier | `src/modules/finance/capabilities/match-supplier/` |
| `finance.match-purchase-order` | finance | R0 | match 现有 PO | `src/modules/finance/capabilities/match-purchase-order/` |
| `finance.detect-duplicate` | finance | R1 | file_hash + entity 重复检测 | `src/modules/finance/capabilities/detect-duplicate/` |
| `finance.validate-expense-draft` | finance | R0 | 业务规则校验（金额 / 必填 / project 必填判断） | `src/modules/finance/capabilities/validate-expense-draft/` |
| `finance.suggest-next-task` | finance | R0 | workflow 完成后建议下一步 | `src/modules/finance/capabilities/suggest-next-task/` |
| `document-intake.classify-document` | document-intake | R1 | LLM-only 分类（哪个 bucket）；LLM 不可用时返回 unknown，不用 keyword heuristic 顶替 | `src/modules/document-intake/capabilities/classify-document/` |

**Risk levels**：
- R0 — 安全 lookup / 计算（无 side effect）
- R1 — 读 +轻度状态判断
- R2 — AI 抽取 / 预测（不写入业务数据）
- R3 — 推荐 + 提示用户决策
- R4 — 写入业务数据（需 user confirmation）
- R5 — 不可逆 / 涉及 IRAS 提交（最严）

注册位置：`src/app/bootstrap/register-ai-capabilities.ts`（启动时调 `registerCapability(...)`）。

### 4.1 Capability 文件结构

每个 capability 一个目录，包含：
- `capability.ts` — 主入口（execute 函数）
- `prompt.ts` — LLM prompt 模板（如有）
- `schema.ts` — Zod 期望输出 schema（如有）
- `heuristic.ts` — 启发式规则（如有）
- `index.ts` — barrel export

例如 `extract-document-fields`：
```
capabilities/extract-document-fields/
├── capability.ts        ← execute()，按 categoryDocType 分支选 prompt+schema；archive contract/quotation/PO 分支见 `src/modules/finance/capabilities/extract-document-fields/capability.ts:179` / `:232`
├── prompts.ts           ← invoice / receipt / PO / customer invoice / contract / quotation prompts；archive prompts 见 `src/modules/finance/capabilities/extract-document-fields/prompts.ts:104` / `:146`
├── schemas.ts           ← 每种 docType 的 zod schema；archive schemas 见 `src/modules/finance/capabilities/extract-document-fields/schemas.ts:90`
├── heuristic.ts         ← 历史正则启发式；Inbox 真实文本路径不再调用
└── index.ts
```

### 4.2 加新 capability 步骤

1. 新建 `src/modules/<owner>/capabilities/<name>/`
2. 写 `capability.ts`：
   ```typescript
   export const myCapability: PlatformCapability<TInput, TOutput> = {
     id: '<owner>.<name>',
     description: '...',
     riskLevel: 'R2',
     async execute(input, ctx) { ... }
   };
   ```
3. 在 `src/modules/<owner>/capabilities/index.ts` aggregate
4. 在 `src/app/bootstrap/register-ai-capabilities.ts` 调 `registerCapability(myCapability, manifest)`
5. manifest 字段：
   ```typescript
   {
     id: '<owner>.<name>',
     ownerModule: 'finance',
     description: '...',
     riskLevel: 'R2',
     allowedAgents: ['finance-agent'],
     requiredUserPermissions: ['finance:view'],
     requiresConfirmation: false,
     auditRequired: true,
     enabled: true
   }
   ```

---

## 5. Document artifact 状态机（document-intake，Ship 2 = inbox 异步流）

### 5.1 14 状态（Ship 2）

```
received                       ← 刚接收，未写 R2
   ↓
stored                         ← 文件已落 R2，POST /api/documents 此时返回 202 + 推队列
   ↓
text_extraction_pending        ← Worker 拿到消息开始处理
   ↓
text_extracted                 ← Browser pdfjs 短路 / 服务端 vision 完成
   ↓ (可选 ocr_pending → ocr_completed)
classification_pending
   ↓
classified                     ← classify-document capability 完成
   ↓
fields_extraction_pending      ← Worker 调 finance.extract-document-fields
   ↓
ready_for_review               ← suggestedFields 写好；artifact 出现在 /finance/inbox
   ↓
(用户在 /finance/inbox/[id] 点 Confirm)
   ↓
confirmed                      ← finance 已写 expenses/revenue + audit；inbox 主标签过滤掉

ready_for_workflow             ← legacy 同步 path 终态（旧 AI Panel）；inbox 也接受
needs_manual_review / failed   ← 任意环节失败的终态
```

**关键转移规则**：
- `classified → fields_extraction_pending → ready_for_review` 仅当调用方给 `processDocument` 传了 `fieldExtractor` callback。Sync dev fallback / 老调用方不传，则跳过 fields 抽取直接 `ready_for_review`（无 suggestedFields）。
- 图像 / 扫描 PDF 首页面 JPEG 不再先做长篇 OCR：AI Panel 预处理为 JPEG（`src/app/ai-panel/components/workflow-panel/layers/finance-document-intake/UploadStep.svelte:101`），`processDocument` 写入 `provider='workers_ai_vision_direct'` 的空 rawText 提取记录，再由 `categoryClassifier` 直接判 category（`src/modules/document-intake/services/document-intake-service.ts:397`）。
- 用户重新选类（`POST /api/documents/[id]/reclassify`）：状态保持 `ready_for_review`，仅替换 `suggestedFields` + `suggestedCategoryId`。是 AI 重新预填、不是状态机转移。
- 用户确认（`POST /api/documents/[id]/confirm`）：finance 写库**成功**后才转 `confirmed`；写库失败状态仍是 `ready_for_review` 让用户重试。

### 5.2 同步 vs 异步两条路径

**异步（Ship 2 主路径，生产部署）**：

```
Browser                                HTTP Worker                    Queue + Document Worker
─────────                              ───────────                    ────────────────────────
upload PDF →                           POST /api/documents
  (pdfjs 抽 client text)               ├─ stored artifact (sync)
                                       ├─ env.DOCUMENT_QUEUE.send(msg)
                                       └─ return 202 view  ─────────→ msg.body
                                                                       └─ document-processor.queue()
                                                                           └─ processDocument({ categoryClassifier, fieldExtractor })
                                                                              ├─ text_extracted (跳过 if 有 client text；图像路径为空 rawText)
                                                                              ├─ classified (图像路径直接由 vision category classifier 判 category)
                                                                              ├─ fields_extraction_pending
                                                                              │   └─ extractDocumentFieldsCapability (text LLM 或 vision JSON)
                                                                              └─ ready_for_review
←──────────  (poll GET /api/documents/[id]/status / SSR /finance/inbox 拉)
```

**同步 fallback**（dev 本地或没起队列）：HTTP Worker 没有 `env.DOCUMENT_QUEUE` 绑定时，直接 inline 调用 `service.processDocument({ fieldExtractor })`。Ship 2C 后 localhost 默认 inline，即使有 `DOCUMENT_QUEUE` binding，也避免本地两个 `wrangler dev` 进程的 queue 消息不互通导致 artifact 停在 `stored`。强测异步 queue 时设 `DOCUMENT_QUEUE_FORCE_ASYNC=true`。

### 5.3 主入口

```typescript
import { createDocumentIntakeService } from '$modules/document-intake';
import {
    extractDocumentFieldsCapability,
    categoryIdForDocumentType,
    findCategoryById
} from '$modules/finance';

const service = createDocumentIntakeService({ db, env, user });

// 接收上传
const artifact = await service.createDocumentFromUpload({
    body, fileName, mimeType, uploadedBy, uploadedFrom, sizeBytes
});

// 推进所有状态（dependency injection 避免 document-intake → finance 倒挂）
await service.processDocument({
    documentId: artifact.id,
    tenantId,
    clientExtractedText,                  // optional pdfjs 输出
    clientExtractionMethod,
    categoryClassifier,                   // optional：图像直读分类（finance.classify-document-category）
    fieldExtractor: async ({ documentType, text, fileName, ... }) => {
        const categoryId = categoryIdForDocumentType(documentType ?? 'unknown');
        if (!categoryId) return null;
        const r = await extractDocumentFieldsCapability.execute(
            { documentId, fileName, text, categoryId },
            { tenantId, userId, env, useMock: !env.AI }
        );
        return { fields: r.fields, confidence: replicate(r.confidence), evidence: r.evidence, categoryId };
    }
});

// 用户操作
await service.markConfirmed({ documentId, entityType, entityId, categoryId });
await service.abandonIntake({ documentId, reason }); // 放弃本次录入；R2 原文件保留到 retention cleanup
await service.replaceSuggestedFields({ documentId, fields, confidence, categoryId });
```

### 5.4 Inbox 路由（Ship 2 用户面）

| 路由 | 方法 | 用途 |
|---|---|---|
| `/finance/inbox` | GET (SSR) | 列表 4 个 tab：Ready / Processing / Confirmed / Needs attention |
| `/finance/inbox/[id]` | GET (SSR) | 单 artifact review 表单（编辑字段 + 改类别 + Confirm） |
| `/api/documents` | POST | Upload + 推队列 + 202 |
| `/api/documents/inbox` | GET | List by status（前端切 tab 时打这个 endpoint） |
| `/api/documents/categories` | GET | Client-safe finance category catalog projection（AI Panel Inbox 表单用） |
| `/api/documents/[id]` | GET | 完整 view（含 suggestedFields） |
| `/api/documents/[id]/intake` | GET | document-intake 诊断 view（含 rawText / extraction metadata / classification candidates / suggestedFields / fieldExtraction evidence / filePreview；仅详情页按需拉取，filePreview URL 指向受角色限制的 `/api/documents/[id]/file`，响应组装见 `src/routes/api/documents/[id]/intake/+server.ts:49` / `:59` / `:82`） |
| `/api/documents/[id]/file` | GET | operator-only 原文件 inline preview（PDF/image 用于 AI Panel document review），服务端读取 artifact `storageRef`，不把 R2 key 暴露给客户端；见 `src/routes/api/documents/[id]/file/+server.ts:15` |
| `/api/documents/[id]/status` | GET | 轻量轮询 |
| `/api/documents/[id]/confirm` | POST | hashConfirmationPayload guard + 写 expenses/revenue + 标 confirmed |
| `/api/documents/[id]/abandon` | POST | 将未落业务表的 artifact 标为 `abandoned`，写 `inbox.intake_abandoned` audit；不删除 R2 原文件（`src/routes/api/documents/[id]/abandon/+server.ts:24`） |
| `/api/documents/[id]/reclassify` | POST | 用新 categoryId 重跑 extract-document-fields，状态不变 |

### 5.5 关键文件

- `src/modules/document-intake/services/document-intake-service.ts` — 主接口（accept fieldExtractor callback）
- `src/modules/document-intake/services/legacy-document-intake-service.ts` — 906 行 v3 实现（doc-hub 等 legacy 路由仍在用）
- `src/modules/document-intake/repositories/document-artifact-repository.ts` — repo（含 listByStatuses / countByStatuses for inbox）
- `src/modules/document-intake/capabilities/classify-document/` — classify capability
- `src/modules/document-intake/workflows/intake-pipeline/pipeline.ts` — 自定义状态机推进逻辑（legacy）
- `src/modules/document-intake/schemas/queue-messages.ts` — `DocumentProcessorMessage` 队列消息合约
- `workers/document-processor.ts` — 队列 consumer
- `workers/wrangler.document-processor.jsonc` — consumer 部署配置
- `src/routes/(app)/finance/inbox/+page.{svelte,server.ts}` — list UI
- `src/routes/(app)/finance/inbox/[id]/+page.{svelte,server.ts}` — review UI
- `src/routes/api/documents/inbox/+server.ts` — 列表 endpoint
- `src/routes/api/documents/[id]/{confirm,abandon,reclassify}/+server.ts` — Inbox flow 写 endpoints

---

## 6. Audit 字段（合规 + 模型评估的真理）

每次 capability 调用 + 每次 confirm write 都写 audit。`auditLogs.metadata` JSON 含：

```typescript
{
  agentId: 'finance-agent',
  agentVersion: '0.3.0',
  workflowId: 'financial-document-intake',
  workflowStep: 'user_confirmation',
  intent: 'record_expense',
  toolId: 'finance.extract-document-fields',
  riskLevel: 'R4',
  inputRefs: { documentId, ... },
  outputRefs: { entityId },
  modelId: 'workers-ai-llama-3.1-8b',
  providerId: 'workers-ai',
  promptVersion: 'v1',
  schemaVersion: 'v1',
  permissionResult: 'allowed',
  confirmationRequired: true,
  confirmationRef: 'sha256:...',         // 用户确认的 payload hash
  finalAction: 'expense.created.sales_cost.invoice',
  status: 'ok' | 'denied' | 'failed',
  errorCode?: 'tool_disabled',
  tenantId: 'default'
}
```

**finalAction** 命名约定：`<entityType>.<verb>.<expenseType>.<docType>`，例如：
- `expense.created.opex.transport`
- `expense.created.sales_cost.invoice`
- `revenue.created`
- `archive.created.contract`
- `expense.created.opex.allowance`

**写 audit 的位置**：
- 业务事件 audit → `AuditService` (`src/platform/audit/audit-service.ts`)
- AI 操作 audit → `appendAgentAuditEntry()` (`src/platform/audit/audit-log.ts`)

详见 `4_平台与基础设施.md` §4。

---

## 7. AI runtime 调用（capability 内部抽字段）

```typescript
import { runStructuredOutput } from '$platform/ai/ai-runtime';
import { z } from 'zod';

const InvoiceFieldsSchema = z.object({
  invoiceNumber: z.string().nullable(),
  vendorName: z.string(),
  totalAmount: z.number(),
  // ...
});

const result = await runStructuredOutput({
  env: ctx.env,
  modelId: 'workers-ai-llama-3.1-8b',
  promptVersion: 'v1',
  schema: InvoiceFieldsSchema,
  prompt: `Extract fields from this supplier invoice text:\n\n<document>${text}</document>`,
  inputRefs: { documentId }
});

// result.data 自动符合 Schema；result.audit 是 audit metadata（model id / token cost / latency / finalAction）
```

**回退策略**（每个 capability 自定义）：
1. `finance.extract-document-fields`：真实文本走 LLM-only；LLM 失败返回空字段 + 0 confidence，不用 regex/mock 顶替（`src/modules/finance/capabilities/extract-document-fields/capability.ts:484`）。
2. 无可用文本或没有 runtime `env` 的直接 demo/unit 调用，`extract-document-fields` 保留 fixture mock fallback（`src/modules/finance/capabilities/extract-document-fields/capability.ts:452`）。
3. 其他 legacy OCR endpoint 仍可能有自己的 heuristic fallback，需看对应 capability / route。

**Prompt 安全**（doc-03 §15 / doc-05 §27.1）：
- 文档内容用 `<document>...</document>` 标签隔离
- Prompt 显式声明"忽略嵌入指令"
- 模型温度 0（结构化输出）

---

## 8. 工作流端点（API）

| Endpoint | 方法 | 功能 |
|---|---|---|
| `/api/finance/workflow` | POST | 启动新 workflow 实例（body: `{ workflowId, agentId, initialStep, data }`），返回 `{ id, state }` |
| `/api/finance/workflow/[id]/advance` | POST | 推进 step（body: `{ step, payload }`），调对应 capabilities，patch state |
| `/api/finance/workflow/[id]/confirm` | POST | 用户最终确认 + 写库（body: `{ payload, payloadHash }`），按 `category.persistTarget` 分发到 expenses/revenue/contracts/quotations/purchase_orders |
| `/api/finance/today-brief` | GET | AI Panel Today's Brief 真实数据；聚合 ready_for_review 计数 + in-flight 计数 + GST 截止信号；返回 `{ items: TodayBriefItem[], greeting: string }`（`src/routes/api/finance/today-brief/+server.ts`） |
| `/api/finance/agent/intent` | POST | 用户文本输入 → `classifyFinanceIntent()` → 返回 intent + suggested workflowId |
| `/api/finance/expenses/detect` | POST | 单图片 OCR + 发票字段抽取（不走 workflow） |
| `/api/documents` | POST | 上传文件 + 跑 documentArtifact 状态机 |
| `/api/documents/[id]/status` | GET | 查 artifact 状态 |
| `/api/documents/[id]/confirm` | POST | Inbox 用户最终确认 + 写库；expenses/revenue 走 finance API，contracts/quotations/purchase_orders 走 `saveDocHubUpload` 写 project archive + legacy `documents` |
| `/api/documents/[id]/abandon` | POST | Inbox 用户放弃本次录入；只标 artifact `abandoned`，不创建业务记录，不删除 R2 原文件 |
| `/api/documents/upload` | POST | 替代上传入口（legacy） |
| `/api/intake/save` | POST | savePanelIntake（legacy panel intake） |
| `/api/doc-hub/upload` | POST | 归档文档上传（contract / quote / PO） |
| `/api/ocr/llm-extract` | POST | LLM 单文档抽取 |
| `/api/ocr/llm-classify` | POST | LLM 单文档分类 |
| `/api/ocr/workers-vision` | POST | Workers AI vision（直接调） |

---

## 9. 其他 workflow

| Workflow | 路径 | 用途 |
|---|---|---|
| `vendor-invoice-intake` | `src/modules/finance/workflows/vendor-invoice-intake/` | Phase 1+2 demo 路径，6 步状态机；保留向后兼容；新功能不要往这里加 |
| `allowance-recording` | `src/modules/finance/workflows/allowance-recording/` | 出差津贴特例（无文件流程）；5 步定义 + 每天 50/45 SGD 速率表 |
| `gst-review-preparation` | `src/modules/finance/workflows/gst-review-preparation/` | GST 季度审核前的数据汇总流程（被 tax 页面引用） |
| `intake-pipeline` | `src/modules/document-intake/workflows/intake-pipeline/` | document-intake 内部状态机推进（不是用户可见 workflow） |

---

## 10. AI Panel UI 结构

```
src/app/ai-panel/components/workflow-panel/
├── PanelTrigger.svelte              ← 浮动按钮 / 全屏触发
├── WorkflowPanel.svelte             ← 主面板壳（task mode 切换）
├── layers/
│   ├── QuickActions.svelte          ← 4 个 Quick Action（录发票 / 登记费用 / 归档合同 / 出差津贴）
│   ├── TodayBrief.svelte            ← Today's Brief（真实数据）：mount 时 fetch GET /api/finance/today-brief；loading skeleton → 真实 BriefItem[] → empty state；失败静默降级
│   ├── TaskLine.svelte              ← 任务列表
│   ├── ActiveFlow.svelte            ← 按 workflowId 分发到对应 layer
│   ├── intake/                      ← 旧 doc-hub 通用流程（保留）
│   ├── finance-invoice/             ← Phase 1+2 vendor-invoice-intake demo（6 step）
│   ├── finance-document-intake/     ← Ship 2C 上传入口；上传后切 finance-inbox
│   ├── finance-inbox/               ← AI Panel Inbox 浮层（复用 /api/documents/inbox + shared confirm form）
│   └── finance-allowance/           ← Phase 3 stage 5 无文件特例
```

每个 step 是一个 Svelte 组件，遵循 props 协议：
- `state` — 当前 workflow state
- `categories` — 当前可选 category 列表
- `onAdvance(payload)` — 调 `/advance` endpoint
- `onAbort()` — 调 abort

---

## 11. 加 / 改 workflow 的 checklist

加新 workflow（如 `payroll-intake`）：

1. **definition**: `src/modules/<owner>/workflows/<wf>/definition.ts` — 定义 step + nextSteps
2. **steps runner**: `src/modules/<owner>/workflows/<wf>/steps.ts` — 每个 step 的执行逻辑
3. **categories（如适用）**: `src/modules/<owner>/workflows/<wf>/categories.ts`
4. **registry**: 加到 `src/modules/<owner>/workflows/index.ts` aggregate
5. **API endpoints**: 在 `/api/<owner>/workflow/+server.ts` 支持新 workflowId（看现有 SUPPORTED_WORKFLOWS 白名单）
6. **UI layer**: `src/app/ai-panel/components/workflow-panel/layers/<wf>/` 创建 step 组件树
7. **ActiveFlow dispatch**: `layers/ActiveFlow.svelte` 加 workflowId 分支
8. **agent intent map**: `src/modules/<owner>/agent/workflow-binding.ts` 加 intent → workflowId 映射
9. **manifest V2**: 模块 manifest `workflows: [...]` 加新 workflowId
10. **更新 BaseLine §3 + §9**

修改现有 step：
- 改 step 逻辑 → `workflows/<wf>/steps.ts`
- 改 step 顺序 / 转移规则 → `workflows/<wf>/definition.ts` 的 nextSteps
- 改 step UI → `layers/<wf>/<StepName>.svelte`
- 改 capability invocation → 修改对应 capability 实现 + `allowedCapabilities` 列表

---

## 12. 调试技巧

| 想看什么 | 看哪 |
|---|---|
| Workflow 实例当前状态 | `wrangler kv:key get wf-state:<id> --binding=KV --local` |
| 某 artifact 进展 | `SELECT * FROM document_artifacts WHERE id = '...'` |
| AI 抽字段的 audit | `SELECT * FROM audit_logs WHERE action LIKE 'agent.%' ORDER BY created_at DESC` |
| Capability 是否注册 | 看 `src/app/bootstrap/register-ai-capabilities.ts`（启动时打印） |
| Tool policy 决策 | `tool-policy.ts` `checkToolPolicy()` 的 decision 对象 reason 字段 |
| LLM 是否真的被调用 | 看 audit metadata 里有没有 `modelId` 字段非空；Inbox field extraction 真实文本应走 `finance.extract-document-fields` LLM-only |
| Heuristic 是否被采用 | Inbox field extraction 不应再出现 `provider: 'heuristic'`；legacy OCR endpoint 仍看各自 metadata |
