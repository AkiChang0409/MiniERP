# SmartFin BaseLine — AI Coding 入口文档

> 这套 8 篇文档是 **SmartFin v4 之后所有 Claude coding session 的唯一入口**。
> 你（AI）不需要也不应该读 `ref_files/v4/` 下的其他文档（那些是历史设计稿与迁移记录），
> BaseLine 是项目当前状态的单一真理（single source of truth）。

---

## 1. 这套文档的目的

旧的 SmartFin 文档群有几个问题：
- 设计稿（`SmartFin_Modular_Design_Principles.md`、`代码架构设计.md`、`phase0-6/` 等）描述目标，不描述现状
- 迁移记录（`SmartFin_Migration_Plan.md`、`smartfin-implementation-status.md`）记录过程，但 v4 迁移完成后已是历史
- 散落的 README 各模块一份，但常常过期
- 新 AI session 启动时要爬十几份文档才能拼出全貌

**BaseLine 的角色**：
- 把"项目当前状态"压缩到 8 篇文档里
- 每一篇职责单一、互不重叠
- 每一项 claim 都给出 file:line citation，AI 可以直接跳到代码
- AI 在 coding 过程中**主动维护这些文档**：写代码改了什么，BaseLine 对应章节也要改

---

## 2. 8 篇文档目录

| # | 文档 | 内容 | 何时该看 |
|---|---|---|---|
| 0 | **0_README.md**（本文）| 索引 + 阅读顺序 + 更新协议 | 每次新 session 必读 |
| 1 | **1_项目与架构.md** | 项目是什么 + 4 层架构 + 6 个模块清单 | 第一次接触项目时必读 |
| 2 | **2_数据模型.md** | 所有表的归属 / FK / 语义 + Drizzle workflow | 改 schema / 写 SQL / 看 ER 关系时 |
| 3 | **3_模块参考.md** | 每个模块的 dossier（id、deps、API、表、服务、workflow、capability） | 在某个模块内改代码前 |
| 4 | **4_平台与基础设施.md** | platform/ 和 infrastructure/ 提供的能力 | 用 audit / config / events / DB 等基础能力时 |
| 5 | **5_AI workflow 运行时.md** | AI Panel + capability registry + workflow 状态机 + financial-document-intake 端到端 | 改 AI 流程 / 加 capability / 调 prompt 时 |
| 6 | **6_开发与守则.md** | build/db/migrate 命令 + 边界 linter + "新代码放哪"决策树 | 任何 coding 前 |
| 7 | **7_未完成工作.md** | boundary linter allowlist / Wave 3.7 / 多租户 / async OCR / 其他 backlog | 接 backlog 任务前 |

---

## 3. 阅读顺序

### 3.1 全新 AI session（第一次接触此项目）

```
0_README.md            ← 5 分钟读完
1_项目与架构.md         ← 10 分钟
6_开发与守则.md         ← 5 分钟（先了解能动什么、不能动什么）
```

读完这三篇就能开始接受具体任务。其余 5 篇按需查阅。

### 3.2 按任务类型查阅

| 用户需求类型 | 必读 BaseLine 章节 | 然后看代码 |
|---|---|---|
| 加新业务字段 / 改 schema | 2_数据模型 + 3_模块参考（对应模块） | 该模块 `repositories/*.schema.ts` |
| 加 / 改一个 finance workflow 步骤 | 5_AI workflow 运行时 + 3_模块参考（finance） | `src/modules/finance/workflows/financial-document-intake/` |
| 加新的 capability（AI 能力） | 5_AI workflow 运行时 + 4_平台与基础设施（platform/ai） | `src/modules/finance/capabilities/<new>/` |
| 加新路由 / 新页面 | 6_开发与守则 + 1_项目与架构（路由命名） + 3_模块参考 | `src/routes/(app)/<module>/` 或 `src/routes/api/<module>/` |
| 改 OCR / 文件上传链路 | 5_AI workflow 运行时 + 3_模块参考（document-intake） | `src/modules/document-intake/services/` |
| 改 GST / 税务 / 报表 | 3_模块参考（finance） | `src/modules/finance/services/{tax,insight}-service.ts` |
| 加 / 改员工 / 项目成员逻辑 | 3_模块参考（hr / project） | `src/modules/hr/services/` + `src/modules/project/repositories/` |
| 改 customer / supplier 主数据 | 3_模块参考（procurement / sales-crm） | supplier → `src/modules/procurement/`；customer → `src/modules/sales-crm/` |
| 调试 boundary linter 报错 | 6_开发与守则 + 7_未完成工作（allowlist） | `scripts/check-modular-boundary.mjs` |
| 重置本地 D1 / 加种子数据 | 6_开发与守则 | `drizzle/seeds/local-mock-full.sql` |

### 3.3 推荐 session 启动 prompt（用户给 AI 的开场白模板）

```
请先读ref_files/v4/erp_dev_plan.html了解项目模块划分预期； ref_files/v4/erp_dev_plan.html了解项目阶段性目标；ref_files/v4/BaseLine/0_README.md 了解项目文档结构，
然后根据我的任务（本次任务集中在 [XXX] module）按 §3.2 表格阅读对应章节，
再根据章节里的 file:line 跳到代码。

任务描述：
    
根据以上user Story检查当前代码实现，有机结合进行新功能的开发，回复用中文。
```

---

## 4. 文档更新协议（AI 改代码后必须维护）

| 改了什么代码 | 必须同步更新的 BaseLine 文档 |
|---|---|
| 新建 / 删除一张数据库表 | `2_数据模型.md` 表清单 |
| 改了 schema 列定义 | `2_数据模型.md` 对应表节 |
| 新增 / 删除一个模块 | `1_项目与架构.md` + `3_模块参考.md` |
| 改了模块 public API（`api.ts` 暴露的方法） | `3_模块参考.md` 对应模块 |
| 加 / 删 capability | `3_模块参考.md` + `5_AI workflow 运行时.md` |
| 加 / 删 workflow 或改 workflow 状态机 | `5_AI workflow 运行时.md` |
| 改 `register-modules.ts` 或 `module-access.ts` | `1_项目与架构.md` 模块清单 + `6_开发与守则.md` |
| 加新路由 prefix | `1_项目与架构.md` + `6_开发与守则.md` 路由约定 |
| 改 platform 抽象（auth / audit / config / files / events / workflow runtime） | `4_平台与基础设施.md` |
| Boundary linter allowlist 新增 / 删除条目 | `7_未完成工作.md` |
| 完成了 `7_未完成工作.md` 列表里的某项 | `7_未完成工作.md` 划掉对应项 + 同步其他相关章节 |

**更新原则**：
- 改代码 → 更新文档是同一个 commit
- 每个 BaseLine 章节都该是"读它就够了"，不要把"详细实现见 X 文档"当借口
- 但也不要把代码细节复制进文档；文档说"是什么 / 在哪 / 怎么调"，代码说"怎么实现"
- file:line citation 是必需的；绝不写"在 finance 服务里"，要写"在 `src/modules/finance/services/tax-service.ts:107`"

---

## 5. 不要看的文档（历史 / 二级参考）

以下文档**只在专门重新设计架构时再看**，日常 coding 不需要：

| 文档 | 历史角色 | 现在为什么不读 |
|---|---|---|
| `ref_files/v4/SmartFin_Modular_Design_Principles.md` | v4 架构原则白皮书 | BaseLine §1+§6 已经把所有 actionable 原则提炼出来 |
| `ref_files/v4/代码架构设计.md` / `Architecture_Design.md` | 架构选型讨论 | 已经选定 modular monolith；当前架构在 BaseLine §1 |
| `ref_files/v4/SmartFin_Current_Implementation_Design.md` | v4 迁移期的"现状 vs 目标"对照 | v4 迁移已完成，对照表过时 |
| `ref_files/v4/SmartFin_Migration_Plan.md` | v4 4 个 Wave 的迁移蓝图 | 已经全部执行完毕 |
| `ref_files/v4/smartfin-implementation-status.md` | v3/AI-Guide phase 1-3 的快照 | 部分内容已被新版超越，部分迁入 BaseLine §5 |
| `ref_files/v4/smartfin-expense-revenue-design.md` | expense/revenue 字段设计源 | categories 真理表在 `src/modules/finance/workflows/financial-document-intake/categories.ts`，而非这份文档 |
| `ref_files/v4/phase0-6/*.md` | AI workflow phase 路线 | phase 1-3 已完成；后续 phase 进 BaseLine §7 backlog |
| 各模块下的 `README.md` | 模块自述文件 | 多数过期；信息已合并到 `3_模块参考.md` |
| 项目根的 `ARCHITECTURE_MIGRATION_TRACKER.md` / `MODULAR_MIGRATION_PHASES.md` / `REFACTOR_OPTIMIZATION_GUIDE.md` | v2/v3 重构期记录 | 历史信息，不再准确 |

如果遇到 BaseLine 信息不够用、需要更深的设计意图，**先尝试通过 file:line 跳到代码读懂**，再回来补充 BaseLine。只有在涉及"为什么当初要这样设计"时才回查上述历史文档。

---

## 6. 简短的项目身份卡

- **名字**：SmartFin
- **定位**：AI-native 模块化财务 / ERP 平台
- **架构形态**：modular monolith（单仓 / 单部署 / 模块边界清晰）
- **目标客户模式**：standalone 单模块交付 + suite 套件交付
- **后端**：Cloudflare Workers + D1 + R2 + KV + Workers AI
- **前端**：SvelteKit (Svelte 5) + Tailwind
- **核心 ORM**：Drizzle (SQLite dialect)
- **认证**：better-auth
- **当前模块清单**：`finance` / `document-intake` / `project` / `hr` / `procurement` / `sales-crm`（6 个业务模块）+ `core`（1 个 platform-internal）
- **代码仓库根**：`C:/Users/akiwc/Documents/Axiom/AR Financial Management System/SmartFin`

---

## 7. 最近一次重大变更（Ship 2，2026-05-07）

异步 Inbox 管线上线：
- **后端**：`POST /api/documents` 推 Cloudflare Queue，独立 worker（`workers/document-processor.ts`）跑 extract → classify → field-extract，artifact 终于 `ready_for_review`
- **前端**：`/finance/inbox`（list） + `/finance/inbox/[id]`（review shell）+ AI Panel `finance-inbox` 浮层；confirm 表单收敛到 `InboxConfirmForm.svelte`
- **API**：`/api/documents/inbox`（list） + `/api/documents/categories`（category projection）+ `/api/documents/[id]/{confirm,reclassify}`（写）
- **Schema**：`documentArtifacts` 加 `suggested_fields` + `suggested_category_id` 列；状态机加 `fields_extraction_pending` / `ready_for_review` / `confirmed`

详见 文档 2 §2.8 + 文档 4 §13.4 + 文档 5 §5。
